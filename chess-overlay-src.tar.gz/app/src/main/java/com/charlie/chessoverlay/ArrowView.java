package com.charlie.chessoverlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.View;

/** Transparent non-interactive arrow layer. All coordinates are screenshot pixels. */
final class ArrowView extends View {
    private final Paint line=new Paint(3);
    private final Paint border=new Paint(3);
    private BoardDetector.Board board;
    private String move;
    ArrowView(Context context){
        super(context);
        line.setColor(0xff248bfa);line.setStrokeWidth(dp(8));line.setStrokeCap(Paint.Cap.ROUND);line.setStrokeJoin(Paint.Join.ROUND);line.setStyle(Paint.Style.STROKE);
        border.setColor(0xff063676);border.setStrokeWidth(dp(12));border.setStrokeCap(Paint.Cap.ROUND);border.setStyle(Paint.Style.STROKE);
        setLayerType(View.LAYER_TYPE_SOFTWARE,null);
    }
    private float dp(float d){return d*getResources().getDisplayMetrics().density;}
    void show(BoardDetector.Board b,String uci){board=b;move=uci;invalidate();}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        if(board==null||move==null||move.length()<4)return;
        float[] a=board.pointFor(move.substring(0,2));float[] b=board.pointFor(move.substring(2,4));
        if(a==null||b==null)return;
        float x=a[0],y=a[1],tx=b[0],ty=b[1];
        float dx=tx-x,dy=ty-y,len=(float)Math.hypot(dx,dy);if(len<1)return;
        float ux=dx/len,uy=dy/len;float endx=tx-ux*dp(10),endy=ty-uy*dp(10);
        c.drawLine(x,y,endx,endy,border);c.drawLine(x,y,endx,endy,line);
        float head=dp(20),wing=dp(13);
        Path arrow=new Path();arrow.moveTo(tx,ty);
        arrow.lineTo(tx-ux*head-uy*wing,ty-uy*head+ux*wing);
        arrow.lineTo(tx-ux*head+uy*wing,ty-uy*head-ux*wing);arrow.close();
        Paint p=new Paint(3);p.setColor(0xff248bfa);p.setStyle(Paint.Style.FILL);c.drawPath(arrow,p);
        p.setColor(0xff063676);p.setStrokeWidth(dp(2));p.setStyle(Paint.Style.STROKE);c.drawPath(arrow,p);
    }
}
