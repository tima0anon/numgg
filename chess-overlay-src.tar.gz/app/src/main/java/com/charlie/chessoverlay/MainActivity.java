package com.charlie.chessoverlay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private static final int OVERLAY = 101;
    private static final int SCREEN_CAPTURE = 102;
    private boolean launching = false;
    private TextView state;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(28), dp(52), dp(28), dp(24));
        root.setBackgroundColor(Color.rgb(18,21,24));
        TextView title = label("♞  Chess Overlay", 28, Color.WHITE, true);
        root.addView(title);
        TextView description = label("Локальный анализ шахматной позиции с плавающей подсказкой поверх доски.", 16, 0xff9daab3, false);
        LinearLayout.LayoutParams desc = new LinearLayout.LayoutParams(-1, -2);
        desc.topMargin=dp(18); desc.bottomMargin=dp(38);
        root.addView(description,desc);
        Button on = createButton("ВКЛЮЧИТЬ",0xff85bd65);
        Button off = createButton("ВЫКЛЮЧИТЬ",0xff353f47);
        root.addView(on); root.addView(off);
        state=label("Выключен",15,0xff9daab3,false);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);
        sp.topMargin=dp(28); root.addView(state,sp);
        TextView note=label("При включении Android попросит разрешить показ поверх других приложений и один раз подтвердить захват экрана для этой сессии. Снимки остаются на телефоне.",13,0xff7d8a94,false);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2); np.topMargin=dp(28);root.addView(note,np);
        setContentView(root);
        on.setOnClickListener(v->begin());
        off.setOnClickListener(v->{launching=false;stopService(new Intent(this,OverlayService.class));state.setText("Выключен");});
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},200);
    }

    private int dp(float n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
    private TextView label(String text,int sp,int color,boolean bold){
        TextView tv=new TextView(this);tv.setText(text);tv.setTextSize(sp);tv.setTextColor(color);tv.setLineSpacing(dp(4),1f);
        if(bold)tv.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return tv;
    }
    private Button createButton(String text,int color){
        Button b=new Button(this); b.setText(text);b.setTextColor(Color.WHITE);b.setAllCaps(false);b.setTextSize(18);
        GradientDrawable bg=new GradientDrawable();bg.setColor(color);bg.setCornerRadius(dp(17));b.setBackground(bg);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(64));p.bottomMargin=dp(15);b.setLayoutParams(p);return b;
    }
    private void begin(){
        launching=true;
        if(!Settings.canDrawOverlays(this)){
            state.setText("Разреши отображение поверх других окон");
            Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));
            startActivityForResult(i,OVERLAY);return;
        }
        askCapture();
    }
    private void askCapture(){
        if(!launching)return;
        MediaProjectionManager pm=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        Intent request;
        if(Build.VERSION.SDK_INT>=34)request=pm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay());
        else request=pm.createScreenCaptureIntent();
        state.setText("Подтверди захват экрана в системном окне");
        startActivityForResult(request,SCREEN_CAPTURE);
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req==OVERLAY){if(Settings.canDrawOverlays(this)&&launching)askCapture();else {launching=false;state.setText("Нет разрешения для плавающего окна");}}
        else if(req==SCREEN_CAPTURE){
            launching=false;
            if(result==RESULT_OK && data!=null){
                Intent i=new Intent(this,OverlayService.class);i.setAction(OverlayService.START);
                i.putExtra("resultCode",result);i.putExtra("resultData",data);
                startForegroundService(i);state.setText("Работает. Открой Chess.com");
            }else state.setText("Захват отменён");
        }
    }
    @Override protected void onResume(){super.onResume();if(!launching && state!=null && OverlayService.running)state.setText("Работает. Открой Chess.com");}
}
