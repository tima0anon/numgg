package com.charlie.chessoverlay;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Closeable;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

/** Local UCI connection to the official ARM64 Stockfish executable bundled as a native lib. */
final class StockfishEngine implements Closeable {
    private final String binary;
    private Process engine;
    private BufferedReader stdout;
    private BufferedWriter stdin;
    StockfishEngine(String nativeLibraryDir){binary=new File(nativeLibraryDir,"libstockfish.so").getAbsolutePath();}
    private void send(String line)throws Exception {stdin.write(line);stdin.write('\n');stdin.flush();}
    private void ensure()throws Exception {
        if(engine!=null&&engine.isAlive())return;
        if(!new File(binary).exists())throw new Exception("Stockfish не найден");
        engine=new ProcessBuilder(binary).redirectErrorStream(true).start();
        stdin=new BufferedWriter(new OutputStreamWriter(engine.getOutputStream(), StandardCharsets.UTF_8));
        stdout=new BufferedReader(new InputStreamReader(engine.getInputStream(),StandardCharsets.UTF_8));
        send("uci");
        String line;int lines=0;
        while((line=stdout.readLine())!=null&&lines++<200){if(line.equals("uciok"))break;}
        if(line==null)throw new Exception("Stockfish завершил работу");
        send("setoption name Threads value 2");send("setoption name Hash value 32");
        send("isready");
        lines=0;while((line=stdout.readLine())!=null&&lines++<50){if(line.equals("readyok"))break;}
    }
    synchronized String bestMove(String fen,int milliseconds)throws Exception {
        ensure();
        send("position fen "+fen);
        send("go movetime "+Math.max(100,Math.min(milliseconds,2000)));
        String line;
        while((line=stdout.readLine())!=null){
            if(line.startsWith("bestmove ")){
                String move=line.split("\\s+")[1];
                return move.matches("[a-h][1-8][a-h][1-8][qrbn]?")?move:null;
            }
            if(line.contains("CRITICAL ERROR"))throw new Exception("недопустимая позиция FEN");
        }
        return null;
    }
    @Override public synchronized void close(){
        try{if(stdin!=null)send("quit");}catch(Exception ignored){}
        if(engine!=null)engine.destroy();engine=null;
    }
}
