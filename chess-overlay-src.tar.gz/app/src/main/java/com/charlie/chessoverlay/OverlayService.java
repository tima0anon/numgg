package com.charlie.chessoverlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.content.pm.ServiceInfo;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class OverlayService extends Service {
    static final String START="chessoverlay.START",STOP="chessoverlay.STOP";
    public static volatile boolean running=false;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private WindowManager wm;
    private WindowManager.LayoutParams panelParams,arrowParams;
    private TextView panel;
    private ArrowView arrows;
    private BoardDetector detector;
    private StockfishEngine stockfish;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader reader;
    private HandlerThread captureThread;
    private boolean waiting=false,processing=false,stopping=false;
    private int width,height,density;
    private String lastFen="";
    private final Runnable loop=new Runnable(){@Override public void run(){requestFrame();}};
    @Override public IBinder onBind(Intent intent){return null;}
    @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);detector=new BoardDetector(getAssets());}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        if(STOP.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
        if(!START.equals(intent.getAction())||running)return START_NOT_STICKY;
        running=true;
        setupNotification();
        addOverlays();
        @SuppressWarnings("deprecation") Intent data=(Intent)intent.getParcelableExtra("resultData");
        int code=intent.getIntExtra("resultCode",0);
        if(data==null){status("Нет разрешения захвата");stopSelf();return START_NOT_STICKY;}
        try{
            MediaProjectionManager manager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection=manager.getMediaProjection(code,data);
            projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){main.post(()->stopSelf());}},main);
            DisplayMetrics dm=new DisplayMetrics();wm.getDefaultDisplay().getRealMetrics(dm);
            width=dm.widthPixels;height=dm.heightPixels;density=dm.densityDpi;
            reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,2);
            captureThread=new HandlerThread("Chess capture");captureThread.start();
            reader.setOnImageAvailableListener(this::onFrame,new Handler(captureThread.getLooper()));
            virtualDisplay=projection.createVirtualDisplay("ChessOverlayScreen",width,height,density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,null);
            stockfish=new StockfishEngine(getApplicationInfo().nativeLibraryDir);
            main.postDelayed(loop,500);
        }catch(Exception ex){status("Ошибка захвата: "+ex.getMessage());main.postDelayed(this::stopSelf,2500);}
        return START_NOT_STICKY;
    }
    private void setupNotification(){
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("overlay","Chess Overlay",NotificationManager.IMPORTANCE_LOW));
        Intent stop=new Intent(this,OverlayService.class);stop.setAction(STOP);
        PendingIntent pending=PendingIntent.getService(this,13,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification note=new Notification.Builder(this,"overlay")
                .setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("Chess Overlay")
                .setContentText("Локальный анализ экрана включён")
                .addAction(android.R.drawable.ic_menu_close_clear_cancel,"Выключить",pending)
                .setOngoing(true).build();
        if(Build.VERSION.SDK_INT>=29)startForeground(13,note,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(13,note);
    }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private void addOverlays(){
        arrows=new ArrowView(this);
        arrowParams=new WindowManager.LayoutParams(-1,-1,WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        // Android 12+ permits pass-through touches under a sufficiently transparent overlay.
        arrowParams.alpha=.72f; arrowParams.gravity=Gravity.TOP|Gravity.LEFT;
        wm.addView(arrows,arrowParams);
        panel=new TextView(this); panel.setText("♞  Поиск доски…");panel.setTextSize(16);panel.setTextColor(Color.WHITE);
        panel.setTypeface(Typeface.DEFAULT,Typeface.BOLD);panel.setGravity(Gravity.CENTER);panel.setPadding(dp(16),dp(10),dp(16),dp(10));
        GradientDrawable background=new GradientDrawable();background.setColor(0xee17212c);background.setCornerRadius(dp(16));
        background.setStroke(dp(1),0xff3475bd);panel.setBackground(background);
        panelParams=new WindowManager.LayoutParams(dp(228),dp(56),WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity=Gravity.TOP|Gravity.LEFT;panelParams.x=dp(16);panelParams.y=dp(100);
        wm.addView(panel,panelParams);
        panel.setOnTouchListener(new View.OnTouchListener(){
            int x,y;float downX,downY;
            @Override public boolean onTouch(View v,MotionEvent ev){
                if(ev.getAction()==MotionEvent.ACTION_DOWN){x=panelParams.x;y=panelParams.y;downX=ev.getRawX();downY=ev.getRawY();return true;}
                if(ev.getAction()==MotionEvent.ACTION_MOVE){
                    panelParams.x=Math.max(0,Math.min(widthOrScreen()-panelParams.width,x+(int)(ev.getRawX()-downX)));
                    panelParams.y=Math.max(0,Math.min(heightOrScreen()-panelParams.height,y+(int)(ev.getRawY()-downY)));
                    wm.updateViewLayout(panel,panelParams);return true;
                }
                return true;
            }
        });
    }
    private int widthOrScreen(){return width>0?width:getResources().getDisplayMetrics().widthPixels;}
    private int heightOrScreen(){return height>0?height:getResources().getDisplayMetrics().heightPixels;}
    private void status(String s){main.post(()->{if(panel!=null)panel.setText(s);});}
    private void requestFrame(){
        if(!running||stopping||reader==null)return;
        if(processing){main.postDelayed(loop,450);return;}
        // Remove our own artwork before capturing, so piece recognition sees the actual board.
        panel.setVisibility(View.INVISIBLE);arrows.setVisibility(View.INVISIBLE);
        main.postDelayed(()->{waiting=true;main.postDelayed(()->{if(waiting){waiting=false;restore();main.postDelayed(loop,1400);}},1100);},120);
    }
    private void onFrame(ImageReader ir){
        Image image=null;
        try{
            image=ir.acquireLatestImage();
            if(image==null||!waiting||processing)return;
            waiting=false;processing=true;
            Image.Plane plane=image.getPlanes()[0];
            int stride=plane.getRowStride(),pixelStride=plane.getPixelStride();
            ByteBuffer buffer=plane.getBuffer();
            android.graphics.Bitmap raw=android.graphics.Bitmap.createBitmap(width+(stride-width*pixelStride)/pixelStride,height,android.graphics.Bitmap.Config.ARGB_8888);
            raw.copyPixelsFromBuffer(buffer);
            android.graphics.Bitmap frame=android.graphics.Bitmap.createBitmap(raw,0,0,width,height);
            raw.recycle();
            worker.execute(()->analyze(frame));
        }catch(Exception ex){processing=false;main.post(this::restore);}finally{if(image!=null)image.close();}
    }
    private void analyze(android.graphics.Bitmap frame){
        try{
            BoardDetector.Board board=detector.recognize(frame);
            if(board==null){status("Доска не найдена");main.post(()->arrows.show(null,null));}
            else {
                String fen=board.fen();
                if(!fen.equals(lastFen)){
                    lastFen=fen;
                    status("♞  Анализ позиции…");
                    String move=stockfish.bestMove(fen,900);
                    if(move!=null&&move.length()>=4){
                        String text=board.moveName(move);
                        main.post(()->arrows.show(board,move));status("♞  "+text);
                    }else {main.post(()->arrows.show(null,null));status("Позиция не подтверждена");}
                }
            }
        }catch(Exception ex){status("Ошибка анализа: "+ex.getMessage());}
        finally {frame.recycle();processing=false;main.post(()->{restore();main.postDelayed(loop,1500);});}
    }
    private void restore(){if(panel!=null)panel.setVisibility(View.VISIBLE);if(arrows!=null)arrows.setVisibility(View.VISIBLE);}
    @Override public void onDestroy(){
        stopping=true;running=false;main.removeCallbacksAndMessages(null);
        if(reader!=null){reader.setOnImageAvailableListener(null,null);reader.close();reader=null;}
        if(virtualDisplay!=null){virtualDisplay.release();virtualDisplay=null;}
        if(projection!=null){projection.stop();projection=null;}
        if(captureThread!=null)captureThread.quitSafely();
        if(stockfish!=null)stockfish.close();worker.shutdownNow();
        if(panel!=null){wm.removeView(panel);panel=null;}
        if(arrows!=null){wm.removeView(arrows);arrows=null;}
        super.onDestroy();
    }
}
