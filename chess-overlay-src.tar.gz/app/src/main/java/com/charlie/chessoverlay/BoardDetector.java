package com.charlie.chessoverlay;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Offline screen detector specifically calibrated for the green Chess.com board and
 * the classic 2-D pieces visible in the supplied screenshot. No network/OCR/accessibility.
 * Does not pretend to support arbitrary chess themes or 3-D piece sets.
 */
public final class BoardDetector {
    private static final int N=64;
    private static final int[] LIGHT={236,236,208},DARK={117,149,84},
            LAST_DARK={186,202,69},LAST_LIGHT={246,247,112};
    private final List<Template> templates=new ArrayList<>();
    private char[][] previous=null;
    private boolean kingRightsWhite=true,kingRightsBlack=true;
    private boolean rookRightsWa=true,rookRightsWh=true,rookRightsBa=true,rookRightsBh=true;
    private boolean castlingInitialized=false;
    private char lastTurn='w';

    private static class Template {
        final char piece;
        final byte[] pixels;
        Template(char piece,byte[] pixels){this.piece=piece;this.pixels=pixels;}
    }
    BoardDetector(AssetManager assets){
        String[] classes={"wr","wn","wb","wq","wk","wp","br","bn","bb","bq","bk","bp"};
        char[] names={'R','N','B','Q','K','P','r','n','b','q','k','p'};
        for(int z=0;z<classes.length;z++){
            for(int i=0;i<8;i++){
                String path="templates/"+classes[z]+i+".png";
                try(InputStream stream=assets.open(path)){
                    Bitmap b=BitmapFactory.decodeStream(stream);
                    if(b!=null){
                        int[] pixels=new int[4096];b.getPixels(pixels,0,64,0,0,64,64);
                        byte[] mask=new byte[4096];
                        for(int j=0;j<4096;j++)mask[j]=(byte)(Color.red(pixels[j])>128?1:0);
                        templates.add(new Template(names[z],mask));b.recycle();
                    }
                }catch(IOException missing){break;}
            }
        }
    }
    public static final class Board {
        final int x,y,size;
        final char[][] screen;
        final boolean whiteBottom;
        final char turn;
        final String castling,ep;
        Board(int x,int y,int size,char[][] screen,boolean whiteBottom,char turn,String castling,String ep){
            this.x=x;this.y=y;this.size=size;this.screen=screen;
            this.whiteBottom=whiteBottom;this.turn=turn;this.castling=castling;this.ep=ep;
        }
        private char get(int r,int c){return whiteBottom?screen[r][c]:screen[7-r][7-c];}
        public String fen(){
            StringBuilder result=new StringBuilder();
            for(int r=0;r<8;r++){
                int empty=0;
                for(int c=0;c<8;c++){
                    char p=get(r,c);
                    if(p=='.')empty++;
                    else {if(empty>0){result.append(empty);empty=0;}result.append(p);}
                }
                if(empty>0)result.append(empty);
                if(r<7)result.append('/');
            }
            result.append(' ').append(turn).append(' ').append(castling).append(' ').append(ep).append(" 0 1");
            return result.toString();
        }
        public float[] pointFor(String square){
            if(square==null||square.length()!=2)return null;
            int file=square.charAt(0)-'a',rank=square.charAt(1)-'1';
            if(file<0||file>7||rank<0||rank>7)return null;
            int c=whiteBottom?file:7-file,r=whiteBottom?7-rank:rank;
            float side=size/8f;
            return new float[]{x+(c+.5f)*side,y+(r+.5f)*side};
        }
        private char pieceAt(String square){
            int file=square.charAt(0)-'a',rank=square.charAt(1)-'1';
            if(file<0||file>7||rank<0||rank>7)return '.';
            return get(7-rank,file);
        }
        public String moveName(String uci){
            if(uci==null||uci.length()<4)return "—";
            char piece=Character.toLowerCase(pieceAt(uci.substring(0,2)));
            String name;
            switch(piece){
                case 'n':name="Конь";break;case 'b':name="Слон";break;
                case 'r':name="Ладья";break;case 'q':name="Ферзь";break;
                case 'k':name="Король";break;case 'p':name="Пешка";break;
                default:name="Ход";
            }
            return name+" "+uci.substring(2,4)+(uci.length()>4?"="+uci.substring(4):"");
        }
    }
    private static class Mask {
        byte[] pixels=new byte[4096];
        int count,whiteCount;
    }
    private int distance(int pixel,int[] rgb){
        int dr=Color.red(pixel)-rgb[0],dg=Color.green(pixel)-rgb[1],db=Color.blue(pixel)-rgb[2];
        return dr*dr+dg*dg+db*db;
    }
    private double sampleScore(Bitmap bitmap,int x,int y,int size){
        float side=size/8f;int right=bitmap.getWidth(),bottom=bitmap.getHeight(),correct=0,total=0;
        for(int r=0;r<8;r++)for(int c=0;c<8;c++){
            int[] exp=(r+c)%2==0?LIGHT:DARK;
            for(float[] z:new float[][]{{.87f,.20f},{.20f,.87f}}){
                int xx=(int)(x+(c+z[0])*side),yy=(int)(y+(r+z[1])*side);
                if(xx<0||xx>=right||yy<0||yy>=bottom)return 0;
                int color=bitmap.getPixel(xx,yy);
                if(distance(color,exp)<42*42 || distance(color,LAST_DARK)<40*40 ||distance(color,LAST_LIGHT)<40*40) correct++;
                total++;
            }
        }
        return (double)correct/total;
    }
    private double edgeScore(Bitmap bitmap,int x,int y,int size){
        double sum=0;int count=0;float side=size/8f;
        for(int r=1;r<8;r++)for(int c=0;c<8;c++){
            int yy=Math.round(y+r*side),xx=(int)(x+(c+.65f)*side);
            if(yy<3||yy+3>=bitmap.getHeight())continue;
            int a=bitmap.getPixel(xx,yy-2),b=bitmap.getPixel(xx,yy+2);
            int dr=Color.red(a)-Color.red(b),dg=Color.green(a)-Color.green(b),db=Color.blue(a)-Color.blue(b);
            sum+=Math.sqrt(dr*dr+dg*dg+db*db);count++;
        }
        return count==0?0:sum/count;
    }
    private int[] findBoard(Bitmap bitmap){
        int w=bitmap.getWidth(),h=bitmap.getHeight();double best=0;int bx=0,by=0,bs=0;
        for(float scale:new float[]{1f,.94f,.88f,.82f,.75f}){
            int size=Math.round(w*scale);if(size>h||size<240)continue;
            int x=(w-size)/2;
            for(int y=0;y<=h-size;y+=4){
                double sc=sampleScore(bitmap,x,y,size);
                if(sc>best){best=sc;bx=x;by=y;bs=size;}
            }
        }
        if(best<.81)return null;
        // The exact top boundary is at the strongest horizontal checkerboard transition.
        int top=by;double edge=-1;
        for(int y=Math.max(2,by-22);y<=Math.min(h-bs-3,by+22);y++){
            double score=edgeScore(bitmap,bx,y,bs)+sampleScore(bitmap,bx,y,bs)*14;
            if(score>edge){edge=score;top=y;}
        }
        if(sampleScore(bitmap,bx,top,bs)<.80)return null;
        return new int[]{bx,top,bs};
    }
    private Mask extract(Bitmap frame,int x,int y,int side){
        Bitmap crop=Bitmap.createBitmap(frame,x,y,side,side);
        Bitmap small=Bitmap.createScaledBitmap(crop,N,N,true);
        int[] pixels=new int[4096];small.getPixels(pixels,0,N,0,0,N,N);
        if(small!=crop)small.recycle();
        crop.recycle();
        int[] rs=new int[103],gs=new int[103],bs=new int[103];int idx=0;
        for(int j=5;j<10;j++)for(int i=4;i<12;i++){
            int p=pixels[j*N+i];rs[idx]=Color.red(p);gs[idx]=Color.green(p);bs[idx++]=Color.blue(p);
        }
        for(int j=6;j<13;j++)for(int i=52;i<61;i++){
            int p=pixels[j*N+i];rs[idx]=Color.red(p);gs[idx]=Color.green(p);bs[idx++]=Color.blue(p);
        }
        Arrays.sort(rs);Arrays.sort(gs);Arrays.sort(bs);
        int bgR=rs[idx/2],bgG=gs[idx/2],bgB=bs[idx/2];
        Mask mask=new Mask();
        for(int j=6;j<58;j++)for(int i=8;i<56;i++){
            int p=pixels[j*N+i],rr=Color.red(p),gg=Color.green(p),bb=Color.blue(p);
            int dr=rr-bgR,dg=gg-bgG,db=bb-bgB;
            if(dr*dr+dg*dg+db*db>42*42){
                mask.pixels[j*N+i]=1;mask.count++;
                if(Math.min(rr,Math.min(gg,bb))>175)mask.whiteCount++;
            }
        }
        return mask;
    }
    private char classify(Mask observed){
        if(observed.count<250)return '.';
        boolean isWhite=observed.whiteCount>(int)(observed.count*.25f);
        int lowest=Integer.MAX_VALUE;char result='?';
        for(Template t:templates){
            if(Character.isUpperCase(t.piece)!=isWhite)continue;
            int delta=0;
            for(int i=0;i<4096;i++)if(t.pixels[i]!=observed.pixels[i])delta++;
            if(delta<lowest){lowest=delta;result=t.piece;}
        }
        if(lowest>1150)return '?'; // Do not advertise an unreliable best move.
        return result;
    }
    private boolean highlighted(Bitmap bitmap,int x,int y,int size,int r,int c){
        float side=size/8f;
        int col=bitmap.getPixel((int)(x+(c+.87f)*side),(int)(y+(r+.20f)*side));
        return distance(col,LAST_DARK)<46*46 ||distance(col,LAST_LIGHT)<36*36;
    }
    private String square(int r,int c,boolean whiteBottom){
        int file=whiteBottom?c:7-c,rank=whiteBottom?7-r:r;
        return ""+(char)('a'+file)+(rank+1);
    }
    private boolean isWhite(char p){return p>='A'&&p<='Z';}
    private boolean isStartingLayout(char[][] screen,boolean whiteBottom){
        String[] start={"rnbqkbnr","pppppppp","........","........","........","........","PPPPPPPP","RNBQKBNR"};
        for(int r=0;r<8;r++)for(int c=0;c<8;c++){
            char p=whiteBottom?screen[r][c]:screen[7-r][7-c];
            if(p!=start[r].charAt(c))return false;
        }
        return true;
    }
    public Board recognize(Bitmap frame){
        int[] pos=findBoard(frame);if(pos==null)return null;
        int x=pos[0],y=pos[1],size=pos[2];float cell=size/8f;
        char[][] board=new char[8][8];int whiteBottomScore=0,kingW=0,kingB=0;
        List<int[]> highlighted=new ArrayList<>();
        for(int r=0;r<8;r++)for(int c=0;c<8;c++){
            int x0=Math.round(x+c*cell),y0=Math.round(y+r*cell);
            int x1=Math.round(x+(c+1)*cell),y1=Math.round(y+(r+1)*cell);
            int w=x1-x0,h=y1-y0;
            if(w<=0||h<=0||x0+w>frame.getWidth()||y0+h>frame.getHeight())return null;
            // Crop square then resize to 64x64. A 1px margin is ignored by the mask.
            Mask mask=extract(frame,x0,y0,Math.min(w,h));
            char piece=classify(mask);if(piece=='?')return null;
            board[r][c]=piece;
            if(piece=='K')kingW++;
            if(piece=='k')kingB++;
            if(piece!='.')whiteBottomScore+=(isWhite(piece)?1:-1)*(r<4?-1:1);
            if(highlighted(frame,x,y,size,r,c))highlighted.add(new int[]{r,c});
        }
        if(kingW!=1||kingB!=1)return null;
        boolean whiteBottom=whiteBottomScore>=0;
        // Chess.com marks the two most recently moved squares. The now-empty origin
        // and occupied destination tell us which side just moved -> other side to move.
        char turn=lastTurn;
        String ep="-";
        if(highlighted.size()==2){
            int[] a=highlighted.get(0),b=highlighted.get(1);
            int[] dest=board[a[0]][a[1]]!='.'&&board[b[0]][b[1]]=='.'?a:
                    board[b[0]][b[1]]!='.'&&board[a[0]][a[1]]=='.'?b:null;
            if(dest!=null){
                char piece=board[dest[0]][dest[1]];
                turn=isWhite(piece)?'b':'w';
                int[] from=dest==a?b:a;
                if(Character.toLowerCase(piece)=='p' && from[1]==dest[1]&&Math.abs(from[0]-dest[0])==2)
                    ep=square((from[0]+dest[0])/2,dest[1],whiteBottom);
            }
        }else if(previous!=null){
            // If highlights are turned off, detect which side has just moved.
            boolean whiteChanged=false,blackChanged=false;
            for(int r=0;r<8;r++)for(int c=0;c<8;c++){
                char old=previous[r][c],now=board[r][c];
                if(old!=now){if(isWhite(old)&&old!='.'||isWhite(now)&&now!='.')whiteChanged=true;
                    if(Character.isLowerCase(old)&&old!='.'||Character.isLowerCase(now)&&now!='.')blackChanged=true;}
            }
            if(whiteChanged&&!blackChanged)turn='b';
            else if(blackChanged&&!whiteChanged)turn='w';
        }else turn=whiteBottom?'w':'b';
        // At the initial arrangement White necessarily moves first, independent of board flip.
        if(isStartingLayout(board,whiteBottom))turn='w';
        lastTurn=turn;
        // Castling rights from a screen image are fundamentally uncertain. Prefer
        // not to invent rights unless both king and home rook are currently present.
        char[][] logical=new char[8][8];
        for(int r=0;r<8;r++)for(int c=0;c<8;c++)logical[r][c]=whiteBottom?board[r][c]:board[7-r][7-c];
        if(!castlingInitialized){
            kingRightsWhite=logical[7][4]=='K';kingRightsBlack=logical[0][4]=='k';
            rookRightsWa=logical[7][0]=='R';rookRightsWh=logical[7][7]=='R';
            rookRightsBa=logical[0][0]=='r';rookRightsBh=logical[0][7]=='r';
            castlingInitialized=true;
        }
        kingRightsWhite &=logical[7][4]=='K';kingRightsBlack &=logical[0][4]=='k';
        rookRightsWa &=logical[7][0]=='R';rookRightsWh &=logical[7][7]=='R';
        rookRightsBa &=logical[0][0]=='r';rookRightsBh &=logical[0][7]=='r';
        StringBuilder rights=new StringBuilder();
        if(kingRightsWhite&&rookRightsWh)rights.append('K');
        if(kingRightsWhite&&rookRightsWa)rights.append('Q');
        if(kingRightsBlack&&rookRightsBh)rights.append('k');
        if(kingRightsBlack&&rookRightsBa)rights.append('q');
        if(previous==null)previous=new char[8][8];
        for(int r=0;r<8;r++)System.arraycopy(board[r],0,previous[r],0,8);
        return new Board(x,y,size,board,whiteBottom,turn,rights.length()==0?"-":rights.toString(),ep);
    }
}
